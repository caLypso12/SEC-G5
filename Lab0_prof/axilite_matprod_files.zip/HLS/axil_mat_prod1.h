
#define MAX_MEM_SIZE 16
// For implementation use size=1024
// For co-simulation you must use a small MEM_SIZE
