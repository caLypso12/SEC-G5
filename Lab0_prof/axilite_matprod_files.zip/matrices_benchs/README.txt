mem_init.c - PC desktop program that generates a binary file to initialize 
             two matrices A and B with random integer elements
             usage: mem_init #size
                    mem_init #N1 #N2 #N3

m4.bin - binary file with randomly initialized A and B matrices of size 4x4.
m4.txt - textual readable version of m4.bin, with pre-calculated results.
